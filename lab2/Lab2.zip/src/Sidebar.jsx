import React from 'react';
import './Sidebar.css';

function Sidebar({ genres, cities, filterByGenre, filterByCity }) {
  return (
    <div className="sidebar">
      <h5>Genres</h5>
      <ul>
        {genres.map((genre, index) => (
          <li key={index} onClick={() => filterByGenre(genre)}>
            {genre}
          </li>
        ))}
      </ul>
      <h5>Cities</h5>
      <ul>
        {cities.map((city, index) => (
          <li key={index} onClick={() => filterByCity(city)}>
            {city}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Sidebar;
