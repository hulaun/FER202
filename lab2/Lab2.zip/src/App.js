import React, { useState } from "react";
import logo from "./logo.svg";
import "./App.css";
import Home from "./Home";
import Header from "./Header";
import Footer from "./Footer";
import Sidebar from "./Sidebar";

function App() {
  const [filter, setFilter] = useState({ genre: null, city: null });

  const genres = ["Nightlife", "Cityscape", "Romantic", "Adventure", "Beach"];
  const cities = [
    "Viet Nam",
    "USA",
    "France",
    "Japan",
    "Spain",
    "China",
    "India",
    "Kerala",
  ];

  const filterByGenre = (genre) => {
    setFilter((prevFilter) => ({ ...prevFilter, genre }));
  };

  const filterByCity = (city) => {
    setFilter((prevFilter) => ({ ...prevFilter, city }));
  };

  return (
    <div className="App">
      <Header />
      <div className="main-content">
        <Sidebar
          genres={genres}
          cities={cities}
          filterByGenre={filterByGenre}
          filterByCity={filterByCity}
        />
        <Home filter={filter} />
      </div>
      <Footer />
    </div>
  );
}

export default App;
